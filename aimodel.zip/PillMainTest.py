import cv2
import numpy as np
import time
from pathlib import Path
def pause():
    # pause
    keycode = cv2.waitKey(0)
    # ESC key to close imshow
    if keycode == 27:
        cv2.destroyAllWindows()
class PillMainTest():

    def main(self):
        # #==================================원본 코드 ==========================
        # img = cv2.imread('C:/Users/throw/panaceaTest/201902071_F.png',cv2.IMREAD_UNCHANGED)
        # rgba = cv2.medianBlur(img, 55)
        # cv2.imshow("img", cv2.resize(img, (600, 600), interpolation=cv2.INTER_LINEAR))
        # pause()
        # #cv2.imwrite('/mnt/c/data/filter_folder/result/' + 'rgba' + '_temp.jpg', rgba)
        # #medianBlur 처리된 이미지를 cv2.cvtColor 함수를 이용하여 GRAY 스케일 이미지로 변환합니다. 이는 이미지를 흑백으로 변환하여 경계 영역을 찾는 데 사용
        # imgray = cv2.cvtColor(rgba, cv2.COLOR_BGRA2GRAY)
        # cv2.imshow("imgray", cv2.resize(imgray, (600, 600), interpolation=cv2.INTER_LINEAR))
        # pause()
        # #cv2.imwrite('/mnt/c/data/filter_folder/result/' + 'imgray' + '_temp.jpg', imgray)
        # #cv2.findContours 함수를 이용하여 GRAY 스케일 이미지에서 경계선을 찾음. 이 함수는 이미지에서 경계선을 찾아 해당 좌표들을 반환. 두 번째 반환값인 contours는 찾아진 경계선의 좌표 정보를 담고 있는 리스트
        # contours, _ = cv2.findContours(imgray, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
        # contours_t = contours[0].transpose()
        # print('contours_t',contours_t)
        # #윤곽선 표시
        # temp = img.copy()
        # cv2.drawContours(temp, contours, -1, (0, 255, 0), 3)
        # cv2.imshow("Contours", cv2.resize(temp, (600, 600), interpolation=cv2.INTER_LINEAR))
        # pause()
        # pause()
        # cv2.imwrite('C:/testImg/' + 'src' + '_temp.jpg', crop_img)
        # pause()
        ##################################이진화 및 노이즈 제거로 꼭짓점 추출######################################

        #img = cv2.imread('C:/Users/throw/panaceaTest/IMAGE2PG.png',cv2.IMREAD_UNCHANGED)
        # 그레이 스케일 이미지로 변환
        #gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        block_size = 31
        C = 0
        # V 채널 추출
        #img = cv2.medianBlur(img, 15)

        #04_25 새로운방법 ================================
        img= cv2.imread('C:/Users/throw/panaceaTest/201803189_001pg.png',cv2.IMREAD_UNCHANGED)
        #img= cv2.imread('C:/Users/throw/panaceaTest/201902071_F.png',cv2.IMREAD_UNCHANGED)
        img_hsv= cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(src=img_hsv, lowerb=np.array([80, 25, 0]), upperb=np.array([179, 255, 255]))
        img_hsv_modify= cv2.bitwise_and(img, img, mask=mask)
        img_mask_gray = cv2.cvtColor(img_hsv_modify, cv2.COLOR_BGR2GRAY)
        thresh, img_bit = cv2.threshold(img_mask_gray, 0, 255, cv2.THRESH_BINARY)

        #외곽선 추출
        contours, _ = cv2.findContours(img_bit, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        #=====================================================
        # hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        #
        # _, _, v = cv2.split(hsv)
        # cv2.imshow("v", cv2.resize(v, (600, 600), interpolation=cv2.INTER_LINEAR))
        # pause()
        # 이진화
        #_, thresh = cv2.threshold(v, 120, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        # 적응형 이진화
        #thresh = cv2.adaptiveThreshold(v, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY_INV, block_size, C)
        #thresh = cv2.adaptiveThreshold(img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, block_size, C)
        cv2.imshow("thresh", cv2.resize(thresh, (600, 600), interpolation=cv2.INTER_LINEAR))
        pause()
        # 노이즈 제거
        # kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        # opening = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel, iterations=5)
        # closing = cv2.morphologyEx(opening, cv2.MORPH_CLOSE, kernel, iterations=5)
        # cv2.imshow("closing", cv2.resize(closing, (600, 600), interpolation=cv2.INTER_LINEAR))
        # pause()
        # contours, _ = cv2.findContours(closing, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        #윤곽선 표시
        temp = img.copy()
        cv2.drawContours(temp, contours, -1, (0, 255, 0), 3)
        cv2.imshow("Contours", cv2.resize(temp, (600, 600), interpolation=cv2.INTER_LINEAR))
        pause()
        # contours 리스트에서 첫 번째 윤곽선 선택
        contour = contours[0]
        print('윤곽선',len(contours))
        # 선택된 윤곽선으로부터 바운딩 박스(bounding box) 계산
        x, y, w, h = cv2.boundingRect(contour)
        print('x, y, w, h :',x,y,w,h)
        # 이미지 crop
        cropped_img = img[y:y + h, x:x + w]

        # contours_t = contours[0].transpose()
        # print('경계선 좌표값',contours_t)# mkc - test
        # print('x 최대값[0]',np.max(contours_t[0]))
        # print('x 최대값[1]',np.max(contours_t[1]))
        # right_x = np.max(contours_t[0]) + 5
        # left_x = np.min(contours_t[0]) - 5
        # right_y = np.max(contours_t[1]) + 5
        # left_y = np.min(contours_t[1]) - 5
        # crop_img = img[left_y:right_y, left_x:right_x]
        # cv2.imshow("img_bitwise_not_bgr", crop_img)
        pause()
        cv2.imwrite('C:/testImg/' + 'src' + '_temp.jpg', cropped_img)
        #&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
        # img_bgr = cv2.imread('C:/Users/throw/panaceaTest/IMAGE3_png.png')
        # cv2.imshow("img_bgr", img_bgr)
        # pause()
        #
        # img_bitwise_not_bgr = cv2.bitwise_not(img_bgr)
        # cv2.imshow("img_bitwise_not_bgr", img_bitwise_not_bgr)
        # pause()
        #
        # img_bitwise_not_bgr2gray = cv2.cvtColor(img_bitwise_not_bgr, cv2.COLOR_BGR2GRAY)
        # cv2.imshow("img_bitwise_not_bgr2gray", img_bitwise_not_bgr2gray)
        # pause()
        #
        # ret, img_binary = cv2.threshold(img_bitwise_not_bgr2gray, 100, 255, cv2.THRESH_BINARY)
        # cv2.imshow("img_binary", img_binary)
        # pause()
        #
        # contours, hierarchy = cv2.findContours(img_binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        # img_contour = cv2.drawContours(img_bgr, contours, -1, (0, 255, 0), 2)
        # cv2.imshow("img_contour", img_contour)
        # pause()
        # $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
        # input_image = cv2.imread("C:/Users/throw/panaceaTest/IMAGE5.png", cv2.IMREAD_UNCHANGED)
        # #입력 이미지를 medianBlur 함수를 이용하여 블러 처리합니다. 이를 통해 이미지의 노이즈를 줄이고 경계선을 부드럽게 만들어 정확한 경계 영역을 찾는 데 도움
        # rgba = cv2.medianBlur(input_image, 55)
        # #rgba = cv2.resize(rgba, (600, 600), interpolation=cv2.INTER_LINEAR)
        # cv2.imshow("rgba", rgba)
        # pause()
        # #cv2.imwrite('/mnt/c/data/filter_folder/result/' + 'rgba' + '_temp.jpg', rgba)
        # #medianBlur 처리된 이미지를 cv2.cvtColor 함수를 이용하여 GRAY 스케일 이미지로 변환합니다. 이는 이미지를 흑백으로 변환하여 경계 영역을 찾는 데 사용
        # imgray = cv2.cvtColor(rgba, cv2.COLOR_BGRA2GRAY)
        # #cv2.imwrite('/mnt/c/data/filter_folder/result/' + 'imgray' + '_temp.jpg', imgray)
        # #cv2.findContours 함수를 이용하여 GRAY 스케일 이미지에서 경계선을 찾음. 이 함수는 이미지에서 경계선을 찾아 해당 좌표들을 반환. 두 번째 반환값인 contours는 찾아진 경계선의 좌표 정보를 담고 있는 리스트
        # contours, _ = cv2.findContours(imgray, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
        # contours_t = contours[0].transpose()
        # print('경계선 좌표값',contours_t)# mkc - test
        # print('x 최대값[0]',np.max(contours_t[0]))
        # print('x 최대값[1]',np.max(contours_t[1]))
        # right_x = np.max(contours_t[0]) + 5
        # left_x = np.min(contours_t[0]) - 5
        # right_y = np.max(contours_t[1]) + 5
        # left_y = np.min(contours_t[1]) - 5
        # crop_img = input_image[left_y:right_y, left_x:right_x]
        # cv2.imshow("img_bitwise_not_bgr", crop_img)
        # pause()
        #$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
        #==============================================================================
        # img_bgr = cv2.imread("C:/Users/throw/panaceaTest/IMAGE5.png", cv2.IMREAD_UNCHANGED)
        # img_bgr = cv2.resize(img_bgr, (600, 600), interpolation=cv2.INTER_LINEAR)
        # lab = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2LAB)
        # l, a, b = cv2.split(lab)
        #
        # clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
        # cl = clahe.apply(l)
        #
        # limg = cv2.merge((cl, a, b))
        # img_bgr = cv2.cvtColor(limg, cv2.COLOR_LAB2BGR)
        # cv2.imshow("img_bgr", img_bgr)
        # pause()
        # # 이미지 블러
        # img_bgr = cv2.medianBlur(img_bgr, 55)
        # # 색상반전
        # img_bitwise_not_bgr = cv2.bitwise_not(img_bgr)
        # cv2.imshow("img_bitwise_not_bgr", img_bitwise_not_bgr)
        # pause()
        # # 이미지를 그레이스케일로 변환
        # imgray = cv2.cvtColor(img_bitwise_not_bgr, cv2.COLOR_BGRA2GRAY)
        # cv2.imshow("imgray", imgray)
        # pause()
        # #for i in range(10,200,10):
        # # ret, img_binary = cv2.threshold(imgray, 60, 250, 0)
        # # cv2.imshow("img_binary", img_binary)
        # # pause()
        # contours, _ = cv2.findContours(imgray, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
        # img_contour = cv2.drawContours(img_bgr, contours, -1, (0, 255, 0), 2)
        # cv2.imshow("img_contour", img_contour)
        # pause()
        # contours_t = contours[0].transpose()
        # print('경계선 좌표값', contours_t)  # mkc - test
        # 각 윤곽선의 좌표 추출
        # contour_coords = []
        # for cnt in contours:
        #     coords = []
        #     for point in cnt:
        #         x, y = point[0]
        #         coords.append((x, y))
        #     contour_coords.append(coords)
        #
        # # 결과 확인
        # print(contour_coords)
        #==================================================================================
        # contours_t = contours[0].transpose()
        # print('경계선 좌표값', contours_t)  # mkc - test
        # # 그림자 제거
        # clahe = cv2.createCLAHE(clipLimit=5.0, tileGridSize=(8, 8))
        # gray_clahe = clahe.apply(gray)
        # cv2.imshow("gray_clahe", gray_clahe)
        # pause()
        # 이진화
        # _, threshold = cv2.threshold(gray_clahe, 120, 255, cv2.THRESH_BINARY)
        # cv2.imshow("threshold", threshold)
        #pause()
        #threshold = cv2.cvtColor(threshold,cv2.COLOR_GRAY2BGR)
        # 외각선 추출
        # contours, hierarchy = cv2.findContours(gray_clahe, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
        # print('contours',contours[0])
        # contours_t = contours[0].transpose()
        # print('경계선 좌표값', contours_t)  # mkc - test
        # right_point_x = np.max(contours_t[0]) + 5
        # left_point_x = np.min(contours_t[0]) - 5
        # right_point_y = np.max(contours_t[1]) + 5
        # left_point_y = np.min(contours_t[1]) - 5
        # left_x, right_x, left_y, right_y = left_point_x, right_point_x, left_point_y, right_point_y
        # crop_img = img_bgr[left_y:right_y, left_x:right_x]
        # crop_img = cv2.cvtColor(crop_img, cv2.COLOR_BGRA2GRAY)
        # trans_mask = crop_img[:,:,3]==0
        # crop_img[trans_mask] = [0, 0, 0, 0]
        #
        # crop_img = cv2.cvtColor(crop_img, cv2.COLOR_BGRA2BGR)
        # # 외각선을 그림에 그림
        # contour_image = np.copy(crop_img)
        # cv2.drawContours(contour_image, contours, -1, (0, 255, 0), 2)
        #
        # # 외각선이 그려진 이미지 출력
        # cv2.imshow('Contours', contour_image)
        # pause()
        # # pause()
        # # img_bitwise_not_bgr = cv2.bitwise_not(img_bgr)
        # # cv2.imshow("img_bitwise_not_bgr", img_bitwise_not_bgr)
        # # pause()
        # # img_bitwise_not_bgr2gray = cv2.cvtColor(img_bitwise_not_bgr, cv2.COLOR_BGR2GRAY)
        # # cv2.imshow("img_bitwise_not_bgr2gray", img_bitwise_not_bgr2gray)
        # # pause()
        # # for i in range(1,31,2):
        # #     blur = cv2.GaussianBlur(img_bitwise_not_bgr2gray, ksize=(i, i), sigmaX=0)
        # #     ret, thresh1 = cv2.threshold(blur, 100, 255, cv2.THRESH_BINARY)
        # #     cv2.imshow("blur", thresh1)
        # #     contours, hierarchy = cv2.findContours(thresh1, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
        # #     print("contours = ", contours)
        # #     pause()
        #
        # # for i in range(30,250,25):
        # #     for j in range(30, 250, 25):
        # #         print('i , j',i,j)
        # #         ret, img_binary = cv2.threshold(img_bitwise_not_bgr2gray, i, j, cv2.THRESH_BINARY)
        # #         cv2.imshow("img_binary", img_binary)
        # #         pause()
        # # gray = cv2.cvtColor(cv2.medianBlur(src, 55), cv2.COLOR_BGRA2GRAY)
        # # ret, binary = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)
        # # binary = cv2.bitwise_not(binary)
        #
        # # contours, hierachy = cv2.findContours(gray, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
        # # contours, hierarchy = cv2.findContours(img_binary, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
        # # print("contours = ", img_binary)
        # # img_contour = cv2.drawContours(img_bgr, contours, -1, (0, 255, 0), 2)
        # # # # cv2.drawContours(img_bgr, [img_binary[0]], 0, (0, 0, 255), 2)
        # # cv2.imshow("img_contour", img_contour)



if __name__ == '__main__':
    main_class = PillMainTest()
    main_class.main()
