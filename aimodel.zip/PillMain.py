import os
import sys
sys.path.append(os.path.dirname(os.path.abspath(os.path.dirname(__file__))))

import aimodel.PillModel as PillModel
import aimodel.ImageSide_circle as ImageSide_circle
import aimodel.ImageSide_ellipse as ImageSide_ellipse
import aimodel.ImageContourCount as ImageContourCount
import sys
import shutil
import configparser
import pandas as pd
import datetime
# rembg 패키지에서 remove 클래스 불러오기
from rembg import remove
import cv2
import numpy as np
# PIL 패키지에서 Image 클래스 불러오기
from PIL import Image
import os


class PillMain():
    # python PillMain.py /mnt/c/IMAGE1.png /mnt/c/IMAGE2.png
    def main(self, image1, image2):
        print("호출됬습니다...")
        # if len(argv) != 3:
        #     print("Argument is wrong")
        #     print("Usage: python PillMain.py [IMAGE1 FULL PATH] [IMAGE2 FULL PATH] [TEXT FILE PATH]")
        #     sys.exit()

        # image1_path = argv[1]
        # image2_path = argv[2]

        # # 이미지 로드
        # image1_path = cv2.imread(image1_path, cv2.IMREAD_UNCHANGED)
        # image2_path = cv2.imread(image2_path, cv2.IMREAD_UNCHANGED)

        # 바이너리 데이터를 디코딩하여 opencv에서 사용할 numpy 배열로 변환-
        image1_path = cv2.imdecode(np.frombuffer(image1.read(), np.uint8), cv2.IMREAD_UNCHANGED)
        image2_path = cv2.imdecode(np.frombuffer(image2.read(), np.uint8), cv2.IMREAD_UNCHANGED)
        print(image1_path)
        print(image2_path)
        # 배경 제거하기
        image1_path = remove(cv2.cvtColor(image1_path, cv2.COLOR_BGRA2RGBA))
        image2_path = remove(cv2.cvtColor(image2_path, cv2.COLOR_BGRA2RGBA))
        
        # 제거 후 다시 BRG을 RGB로 변환
        image1_path = cv2.cvtColor(image1_path, cv2.COLOR_BGRA2RGBA)
        image2_path = cv2.cvtColor(image2_path, cv2.COLOR_BGRA2RGBA)

        # #CSV파일 로드
        # data_info = pd.read_csv(text_file_path, delimiter='\t')
        # ori_shape = data_info['shape'][0]
        # f_text = data_info['f_text'][0]
        # b_text = data_info['b_text'][0]
        # drug_list_ori = data_info['drug_code'][0].replace('[','').replace(']','').replace(' ','').split(',')

        ori_shape = 'circle'
        f_text = 'none'
        b_text = 'none'
        drug_list_ori = 'none'

        if drug_list_ori[0] == 'none':
            drug_list = drug_list_ori[0]
        else:
            drug_list = drug_list_ori

        # nowdate = datetime.datetime.now().strftime('%y%m%d_%H%M%S')
        # #log_path = '/data/pred_log/'+nowdate+'.log' - MKC
        # log_path = './data/pred_log/nowdate.txt'
        # f=open(log_path,'a')

        shape_list = ['circle', 'ellipse', 'triangle', 'diamond', 'pentagon', 'hexagon', 'octagon', 'square', 'etc']
        if ori_shape not in shape_list:
            print("SHAPE : circle, ellipse, triangle, diamond, pentagon, hexagon, octagon, square, and etc")
            sys.exit()

        # if circle and ellipse shape, judgment both side or one side
        # 원과 타원의 모양인 경우, 양쪽 또는 한쪽을 판단
        if ori_shape == 'circle':
            imageside = ImageSide_circle.ImageContour()
            proportion = 4.7
            _, image1_result, contourcnt1 = imageside.Process(image1_path, proportion)
            _, image2_result, contourcnt2 = imageside.Process(image2_path, proportion)

        elif ori_shape == 'ellipse':
            imageside = ImageSide_ellipse.ImageContour()
            proportion = 5.5
            _, image1_result, contourcnt1 = imageside.Process(image1_path, proportion)
            _, image2_result, contourcnt2 = imageside.Process(image2_path, proportion)

        else:
            imagecontourcount = ImageContourCount.ImageContour()
            proportion = 4.7
            contourcnt1 = imagecontourcount.Process(image1_path, proportion)
            contourcnt2 = imagecontourcount.Process(image2_path, proportion)

        # choice one input image
        choiceimage = PillModel.ChoiceImage()
        if ori_shape in ('circle', 'ellipse'):
            # if input text count is two, shape is 'BOTH'
            if f_text != 'none' and b_text != 'none':
                shape, image_path = choiceimage.ChoiceImage(ori_shape, image1_result, image2_result, contourcnt1, contourcnt2, image1_path, image2_path, True)
            else:
                shape, image_path = choiceimage.ChoiceImage(ori_shape, image1_result, image2_result, contourcnt1, contourcnt2, image1_path, image2_path)
        else:
            image_path = choiceimage.ChoiceImageContour(contourcnt1, contourcnt2, image1_path, image2_path)
            shape = ori_shape

        # f.write(shape+'\n')
        # f.write(image_path+'\n')

        # config file load for each shape
        config = configparser.ConfigParser()
        shape_path = './aimodel/data/prodict config file/'

        if shape == 'circle_BOTH':
            config_file = shape_path + 'config_circle_BOTH.ini'
        elif shape == 'circle_ONESIDE':
            config_file = shape_path + 'config_circle_ONESIDE.ini'
        elif shape == 'ellipse_BOTH':
            config_file = shape_path + 'config_ellipse_BOTH.ini'
        elif shape == 'ellipse_ONESIDE':
            config_file = shape_path + 'config_ellipse_ONESIDE.ini'
        elif shape == 'triangle':
            config_file = shape_path + 'config_triangle.ini'
        elif shape == 'diamond':
            config_file = shape_path + 'config_diamond.ini'
        elif shape == 'pentagon':
            config_file = shape_path + 'config_pentagon.ini'
        elif shape == 'hexagon':
            config_file = shape_path + 'config_hexagon.ini'
        elif shape == 'octagon':
            config_file = shape_path + 'config_octagon.ini'
        elif shape == 'square':
            config_file = shape_path + 'config_square.ini'
        elif shape == 'etc':
            config_file = shape_path + 'config_etc.ini'
        
        config.read(config_file, encoding='UTF-8')
        pillModel = PillModel.PillModel(config['pill_model_info']) 
        
        # image processing
        pillModel.pill_image_process(image_path)
        
        # image open
        img = pillModel.testImage(pillModel.absGetPath()+config['pill_model_info']['make_folder_path'])
        
        # model loading
        pillModel.pill_shape_conf(shape)
        pillModel.pill_model_loading(config['pill_model_info'])

        # prediction
        output = pillModel.pill_prediction(img)
        indices_top, includ_count = pillModel.pill_sorting(output, drug_list)

        # if shape_oneside( or shape_both) model training drug code is not in drug list, try shape_both (or shape_oneside) model
        if (includ_count == 0) and (ori_shape in ('circle','ellipse')):
            if shape == ori_shape+'_ONESIDE':
                shape = ori_shape+'_BOTH'
                config_file = shape_path + 'config_' + shape + '.ini'

            else:
                shape = ori_shape+'_ONESIDE'
                config_file = shape_path + 'config_' + shape+'.ini'

            # f.write(shape+'\n')

            config.read(config_file, encoding='UTF-8')
            pillModel = PillModel.PillModel(config['pill_model_info']) 
            pillModel.pill_shape_conf(shape)
            pillModel.pill_model_loading(config['pill_model_info'])

            output = pillModel.pill_prediction(img)
            indices_top, includ_count = pillModel.pill_sorting(output, drug_list)


        # result = []
        # result = pillModel.pill_information(indices_top)
        # print("결과가 나왔다")
        # print(result)
        # print("그래서 타입은")
        # print(type(result))
        # return result  # 랭크와 의약품식별코드 반환

        print(pillModel.pill_information(indices_top))
        return pillModel.pill_information(indices_top)  # 랭크와 의약품식별코드 반환
        
        
        # f.write(pillModel.pill_information(indices_top))
        # f.close()

        # remove filter image folder
        shutil.rmtree(pillModel.absGetPath()+config['pill_model_info']['make_folder_path'])
    
# if __name__ == '__main__':
#     main_class = PillMain()
#     main_class.main(sys.argv)

    