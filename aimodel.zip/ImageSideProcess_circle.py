import cv2
import numpy as np


class ImageProcess():
    def __init__(self):
        pass

    def max_con_CLAHE(self, img):
        lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        
        clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8,8))
        cl = clahe.apply(l)

        limg = cv2.merge((cl,a,b))
        img = cv2.cvtColor(limg, cv2.COLOR_LAB2BGR)

        return img

    #이미지에서 물체의 각 꼭지점의 좌표를 구하는 함수
    def ImageArea(self, input_image):
        #입력 이미지를 medianBlur 함수를 이용하여 블러 처리합니다. 이를 통해 이미지의 노이즈를 줄이고 경계선을 부드럽게 만들어 정확한 경계 영역을 찾는 데 도움
        rgba = cv2.medianBlur(input_image, 55)
        #cv2.imwrite('/mnt/c/data/filter_folder/result/' + 'rgba' + '_temp.jpg', rgba)
        #medianBlur 처리된 이미지를 cv2.cvtColor 함수를 이용하여 GRAY 스케일 이미지로 변환합니다. 이는 이미지를 흑백으로 변환하여 경계 영역을 찾는 데 사용
        imgray = cv2.cvtColor(rgba, cv2.COLOR_BGRA2GRAY)
        #cv2.imwrite('/mnt/c/data/filter_folder/result/' + 'imgray' + '_temp.jpg', imgray)
        #cv2.findContours 함수를 이용하여 GRAY 스케일 이미지에서 경계선을 찾음. 이 함수는 이미지에서 경계선을 찾아 해당 좌표들을 반환. 두 번째 반환값인 contours는 찾아진 경계선의 좌표 정보를 담고 있는 리스트
        contours, _ = cv2.findContours(imgray, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
        contours_t = contours[0].transpose()

        right_point_x = np.max(contours_t[0]) + 5
        left_point_x = np.min(contours_t[0]) - 5
        right_point_y = np.max(contours_t[1]) + 5
        left_point_y = np.min(contours_t[1]) - 5

        return left_point_x, right_point_x, left_point_y, right_point_y


    def CropShape(self, input_image):
        left_x, right_x, left_y, right_y = self.ImageArea(input_image)
        crop_img = input_image[left_y:right_y, left_x:right_x]
        # print('test')
        # cv2.imwrite('/mnt/c/data/filter_folder/result/' + 'crop' + '_temp.jpg', crop_img) - mkc
        trans_mask = crop_img[:,:,3]==0
        crop_img[trans_mask] = [0, 0, 0, 0]
        crop_img = cv2.cvtColor(crop_img, cv2.COLOR_BGRA2BGR)
        return crop_img

